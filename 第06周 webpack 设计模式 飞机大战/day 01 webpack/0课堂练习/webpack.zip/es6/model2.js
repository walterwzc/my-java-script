class Hello{
	constructor(name){
		this.name = name;
	}
	say(){		
		alert(this.name);
	}
}
//return ;
export default Hello;