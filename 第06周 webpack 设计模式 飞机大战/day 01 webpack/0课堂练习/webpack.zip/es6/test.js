
/*

	用es6进行编写 => 希望可以转译成 es5 
		
	写了一个模块 a;


*/
if(true){
	let a = 10;
	const b = 20;
}
class a{
	constructor(){
		this.name = "hello world";
	}
	say(){
		alert(this.name);
	}
}
