/*功能模块*/
console.log("i'm main")