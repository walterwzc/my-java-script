/*业务逻辑*/
require("./model.js");
require("./es6/test.js");
// require("style-loader!css-loader!./style.css");
// require("style-loader!css-loader!./reset.css");
require("./style.css");
require("./reset.css");
import Hel from "./es6/model2.js";
document.onclick = function(){
	new Hel("你好").say();	
}
console.log("hello world");
