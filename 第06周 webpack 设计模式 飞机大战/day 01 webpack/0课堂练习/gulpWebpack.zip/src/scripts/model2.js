function Hello(){
	this.name = "hello world i'm model2";
}

export default Hello;