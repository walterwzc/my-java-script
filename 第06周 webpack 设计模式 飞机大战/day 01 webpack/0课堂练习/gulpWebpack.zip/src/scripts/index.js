console.log("hello i'm index.js");
require("./model1.js");
import hello from "./model2.js";
require("./../css/style.css");
